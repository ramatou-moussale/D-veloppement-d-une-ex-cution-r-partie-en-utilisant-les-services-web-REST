from flask import Flask, request, jsonify
import time
from shared import *

app_master = Flask(__name__)

tasks_to_do = [(i, *ingredient) for i, ingredient in enumerate(INGREDIENTS)]
tasks_being_done = {}
start_time = None

@app_master.route('/')
def index_master():
    return "Master Server for Distributed Execution Simulation using Flask."

@app_master.route('/ask_task', methods=['GET'])
def ask_task():
    global tasks_to_do, tasks_being_done, start_time
    
    if start_time is None:
        start_time = time.time()

    task = None
    if tasks_to_do:
        task = tasks_to_do.pop()
        id_, fruit, _ = task
        tasks_being_done[id_] = task
        log_master(f"1 {fruit} envoyée à la préparation", id_, OUT_LABEL)

    if task:
        return jsonify({"task": task})
    else:
        return jsonify({"message": "Aucune tâche disponible pour le moment."}), 200

@app_master.route('/send_result', methods=['POST'])
def send_result():
    data = request.get_json()
    task = tuple(data['task'])
    result = data['result']
    
    id_, _, _ = task
    tasks_being_done.pop(id_)

    log_master(f"{result} reçue", task[0], IN_LABEL)
    
    return jsonify({"message": "Résultat reçu avec succès."}), 200

if __name__ == "__main__":
    app_master.run(host='localhost', port=5001)
