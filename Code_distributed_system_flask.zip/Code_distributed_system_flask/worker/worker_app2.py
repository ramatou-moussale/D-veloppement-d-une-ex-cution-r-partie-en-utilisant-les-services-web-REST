from flask import Flask, jsonify, request
import time
import requests
from shared import *

app_worker = Flask(__name__)

master_url = 'http://localhost:5001'

@app_worker.route('/')
def index_worker():
    return "Worker Server for Distributed Execution Simulation using Flask."

def prepare_fruit(id_, fruit, t):
    log_slave(f"1 {fruit} en préparation ({t}s)", id_, WORKING_LABEL)
    time.sleep(t)
    return f"1 {fruit} préparée"

@app_worker.route('/execute_task', methods=['GET'])
def execute_task():
    response = requests.get(f"{master_url}/ask_task")
    data = response.json()

    if 'task' in data:
        task = tuple(data['task'])
        id_, fruit, t = task
        log_slave(f"1 {fruit} à préparer reçue", id_, IN_LABEL)
        
        prepared_fruit = prepare_fruit(id_, fruit, t)
        log_slave(f"1 {fruit} prête envoyée", id_, OUT_LABEL)
        
        result_response = {"task": task, "result": prepared_fruit}
        requests.post(f"{master_url}/send_result", json=result_response)
        return jsonify({"message": f"{fruit} a été préparée."}), 200
    else:
        return jsonify({"message": "Aucune tâche disponible pour le moment."}), 200

if __name__ == "__main__":
    app_worker.run(host='localhost', port=5003)
